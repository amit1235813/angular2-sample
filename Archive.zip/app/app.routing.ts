import {Routes, RouterModule} from "@angular/router";

import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { ArtComponent } from './art/art.component';


//Allsow for Google crawlers?

const APP_ROUTES: Routes=[
	{path : '',component: HomeComponent},
	{path : 'about',component: AboutComponent},
	{path : 'contact',component: ContactComponent},
	{path : ':artPage',component: ArtComponent}

                     
];

export const Routing = RouterModule.forRoot(APP_ROUTES);