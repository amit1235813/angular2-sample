import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'; //For the mapping of an observable to an object
import { ActivatedRoute } from "@angular/router";


@Injectable()
export class ArtService {
	artType: any;
	getData: any;
	handleError: any;

	constructor(private http: Http, private activatedRoute: ActivatedRoute) {
		activatedRoute.params.subscribe(
			(param: any) => { this.artType = param['artPage'];
		}); 
		this.getData = function() {
			return http.get('app/json/' + this.artType + '.json')
			.map((response: Response) => response.json())
		}
	}
}