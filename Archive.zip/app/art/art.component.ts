import { Component, OnDestroy } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
import { Subscription } from "rxjs/Rx";
import { ArtService } from '../art.service';

@Component({
  selector: 'app-art',
  templateUrl: './art.component.html',
  styleUrls: ['./art.component.css'],
  providers: [ArtService]
})
export class ArtComponent implements OnDestroy {
  artWork: any;
  toggleDisplay: any;
  artType: any;
  private subscription: Subscription;
  public test = 5;

  constructor(private artService: ArtService, private activatedRoute: ActivatedRoute) { 
    this.subscription = activatedRoute.params.subscribe( //Subscribes to the live stream of route parameters, if any change happens, this function is executed
      //Resolves the issue of loading fresh parameters using the artService on re-rendering of component when the route changes
      (param: any) => {
        this.artWork = this.artService.getData()
        .subscribe(
          (data) => this.artWork = data
          );
        this.artType = this.artService.artType; //References variables from the artService rather than writing code here
      }); 
    this.toggleDisplay = function (image) {
      image.toggle = !image.toggle;
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}