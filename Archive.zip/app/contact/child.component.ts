import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']

})
export class ChildComponent implements OnInit {
	@Input() result: number = 0;

	@Output() nestedEvent = new EventEmitter();

	 myEvent() {
		this.nestedEvent.emit('Are you listening?');
	}

  constructor() { }

  ngOnInit() {
  }

}
