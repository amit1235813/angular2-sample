import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';


import { User } from './user';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  //Template driven form
  submitted = false;
  model = new User('', '', '');

  onSubmit() {
    this.submitted = true;
  }

  //Reactive form
  reactiveForm: FormGroup;
  user = new User();


  reactiveSubmitted = false;

  onReactiveSubmit() {
    this.reactiveSubmitted = true;
    this.user = this.reactiveForm.value;
  }

  constructor(private formBuilder: FormBuilder) {

  }

  ngOnInit() {
    this.buildForm();


  }

  buildForm() {
    this.reactiveForm = this.formBuilder.group({
      reactiveName: [this.user.name, Validators.compose([Validators.required, Validators.minLength(4),
        Validators.maxLength(24)])
      ],
      reactiveEmail: [this.user.email, Validators.required],
      reactiveMessage: [this.user.message, Validators.required]

    });

    this.reactiveForm.valueChanges
    .subscribe(data => this.onValueChanged(data));
    this.onValueChanged(); // (re)set validation messages now
  }


  onValueChanged(data?: any) {
    if (!this.reactiveForm) { return; }
    const form = this.reactiveForm;
    for (const field in this.formErrors) {
      // clear previous error message (if any)
      this.formErrors[field] = '';
      const control = form.get(field);
      if (control && control.dirty && !control.valid) {
        const messages = this.validationMessages[field];
        for (const key in control.errors) {
          this.formErrors[field] += messages[key] + ' ';
        }
      }
    }
  }

  formErrors = {
    'reactiveName': '',
    'reactiveEmail': '',
    'reactiveMessage': ''
  };

  validationMessages = {
    'reactiveName': {
      'required':      'Name is required.',
      'minlength':     'Name must be at least 4 characters long.',
      'maxlength':     'Name cannot be more than 24 characters long.'
    },
    'reactiveEmail': {
      'required': 'Email is required.'
    },
    'reactiveMessage': {
      'required': 'Message is required.'
    }
  };



  //Nesting
  result = 10;

  myEvent(value) {
    alert(value + ' - Parent says yes.');
  }


}

