import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  constructor() {  }

  ngOnInit() {
  }

}

// class Base {
// 	private name : string;
//   constructor(name) { this.name = name; }

//   ngOnInit() {
//   }

// }

// // console.log(new HomeComponent('Rahul').name);
// class Person extends Base {
// 	constructor(name) {
// 		super(name);
// 	}
// }

// class Blogger  {
// 	private name : string;
//   	constructor(name) { this.name = name; }
// }

// let base = new Base('base');
// let person = new Person('person');
// let blogger = new Blogger('blogger');

// //base = person;
// base = blogger;

class Person {
	public name: string;
	readonly dreams: string;
	constructor(name) {
		this.dreams = 'My Dreams';
		this.dreams = 'New Dreams';
		this.name = name + this.dreams;
	}
}

class Blogger extends Person {
	public blog: string;
	public message: string;
	constructor(name, blog) {
		super(name);
		this.blog = blog;
		this.message = `${this.name} + has a blog named: ${this.blog}`;
	}
	getMessage() {
		console.log(this.message);
	}
}

let blogger1 = new Blogger('Rahul', 'My Blog');
// blogger1.getMessage();
// console.log(blogger1.blog);
// console.log(blogger1.name);
let person1 = new Person('Roy');
console.log(person1.name);
// person1.dreams = 'New Dreams';

